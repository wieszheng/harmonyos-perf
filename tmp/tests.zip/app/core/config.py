class Settings:
    PROJECT_NAME = "鸿蒙App场景化性能测试平台"
    VERSION = "0.1.0"
    DATABASE_URL = "sqlite+aiosqlite:///./test.db"
    # 可扩展数据库、日志等配置

settings = Settings() 