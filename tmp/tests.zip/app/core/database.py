from databases import Database
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine, MetaData
from app.core.config import settings

database = Database(settings.DATABASE_URL)
metadata = MetaData()
Base = declarative_base()
engine = create_engine(settings.DATABASE_URL.replace("+aiosqlite", ""), connect_args={"check_same_thread": False}) 