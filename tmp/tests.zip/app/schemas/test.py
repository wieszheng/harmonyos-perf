from pydantic import BaseModel

class TestOut(BaseModel):
    id: int
    task_id: int
    result: str
    status: str
    progress: float
    cancelled: bool

    class Config:
        orm_mode = True 