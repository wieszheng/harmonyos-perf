from pydantic import BaseModel

class ReportOut(BaseModel):
    id: int
    task_id: int
    file_path: str
    status: str

    class Config:
        orm_mode = True 