from pydantic import BaseModel
from typing import Optional

class TaskCreate(BaseModel):
    name: str

class TaskOut(BaseModel):
    id: int
    name: str
    status: str

    class Config:
        orm_mode = True 