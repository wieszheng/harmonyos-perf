from sqlalchemy import Column, Integer, String
from app.core.database import Base

class Report(Base):
    __tablename__ = 'reports'
    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, index=True)
    file_path = Column(String)
    status = Column(String, default="generated") 