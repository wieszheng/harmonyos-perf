from sqlalchemy import Column, Integer, String, Boolean, Float
from app.core.database import Base

class Test(Base):
    __tablename__ = 'tests'
    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, index=True)
    result = Column(String)
    status = Column(String, default="running")
    progress = Column(Float, default=0.0)
    cancelled = Column(Boolean, default=False) 