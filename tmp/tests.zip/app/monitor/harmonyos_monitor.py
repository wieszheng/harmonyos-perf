import asyncio
import random
from datetime import datetime

class HarmonyOSMonitor:
    def __init__(self, device_id: str, package_name: str, scene: str):
        self.device_id = device_id
        self.package_name = package_name
        self.scene = scene
        self.running = False
        self.data = []

    async def collect_cpu(self):
        # 实际应调用hdc shell命令采集CPU
        await asyncio.sleep(0.1)
        return random.uniform(5, 50)  # mock数据

    async def collect_memory(self):
        await asyncio.sleep(0.1)
        return random.uniform(50, 300)  # mock数据

    async def collect_fps(self):
        await asyncio.sleep(0.1)
        return random.uniform(20, 60)  # mock数据

    async def monitor(self, duration=10, interval=1):
        self.running = True
        start_time = datetime.now()
        while (datetime.now() - start_time).seconds < duration and self.running:
            cpu = await self.collect_cpu()
            mem = await self.collect_memory()
            fps = await self.collect_fps()
            timestamp = datetime.now().isoformat()
            self.data.append({
                "timestamp": timestamp,
                "cpu": cpu,
                "memory": mem,
                "fps": fps
            })
            await asyncio.sleep(interval)
        self.running = False
        return self.data

    def stop(self):
        self.running = False 