from app.core.database import database
from app.models.report import Report
from sqlalchemy import select

async def list_reports_logic():
    query = select(Report)
    return await database.fetch_all(query)

async def get_report_logic(report_id: int):
    query = select(Report).where(Report.id == report_id)
    return await database.fetch_one(query)

async def download_report_logic(report_id: int):
    # 实际下载逻辑可根据file_path实现
    report = await get_report_logic(report_id)
    return report 