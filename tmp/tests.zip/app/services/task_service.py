from app.core.database import database
from app.models.task import Task
from sqlalchemy import select, insert
from app.schemas.task import TaskCreate

async def create_task_logic(task: TaskCreate):
    query = insert(Task).values(name=task.name, status="pending")
    task_id = await database.execute(query)
    return task_id

async def list_tasks_logic():
    query = select(Task)
    return await database.fetch_all(query)

async def get_task_logic(task_id: int):
    query = select(Task).where(Task.id == task_id)
    return await database.fetch_one(query) 