from app.core.database import database
from app.models.test import Test
from sqlalchemy import select, insert, update
from app.monitor.harmonyos_monitor import HarmonyOSMonitor
import asyncio
from app.api.test import active_connections

async def update_test_progress(task_id: int, progress: float):
    query = update(Test).where(Test.task_id == task_id).values(progress=progress)
    await database.execute(query)

async def is_test_cancelled(task_id: int):
    query = select(Test.cancelled).where(Test.task_id == task_id)
    result = await database.fetch_one(query)
    return result and result[0]

async def cancel_test_logic(task_id: int):
    query = update(Test).where(Test.task_id == task_id).values(cancelled=True, status="cancelled")
    await database.execute(query)

async def run_test_logic(task_id: int, device_id: str, package_name: str, scene: str):
    monitor = HarmonyOSMonitor(device_id, package_name, scene)
    duration = 10
    interval = 1
    # 先插入一条记录，标记为running
    query = insert(Test).values(task_id=task_id, result="", status="running", progress=0.0, cancelled=False)
    test_id = await database.execute(query)
    monitor_data = []
    from datetime import datetime
    start_time = datetime.now()
    ws = active_connections.get(task_id)
    while (datetime.now() - start_time).seconds < duration:
        if await is_test_cancelled(task_id):
            await update_test_progress(task_id, 0.0)
            if ws:
                await ws.send_json({
                    "progress": 0.0,
                    "status": "cancelled",
                    "data": None
                })
            break
        cpu = await monitor.collect_cpu()
        mem = await monitor.collect_memory()
        fps = await monitor.collect_fps()
        timestamp = datetime.now().isoformat()
        monitor_data.append({
            "timestamp": timestamp,
            "cpu": cpu,
            "memory": mem,
            "fps": fps
        })
        progress = ((datetime.now() - start_time).seconds + 1) / duration * 100
        await update_test_progress(task_id, min(progress, 100.0))
        # 实时推送数据和进度
        if ws:
            await ws.send_json({
                "progress": min(progress, 100.0),
                "status": "running",
                "data": {
                    "timestamp": timestamp,
                    "cpu": cpu,
                    "memory": mem,
                    "fps": fps
                }
            })
        await asyncio.sleep(interval)
    # 结束后更新结果和状态
    status = "cancelled" if await is_test_cancelled(task_id) else "finished"
    query = update(Test).where(Test.task_id == task_id).values(result=str(monitor_data), status=status, progress=100.0)
    await database.execute(query)
    # 推送最终状态
    ws = active_connections.get(task_id)
    if ws:
        await ws.send_json({
            "progress": 100.0,
            "status": status,
            "data": "finished" if status == "finished" else None
        })
    return monitor_data

async def get_test_status_logic(task_id: int):
    query = select(Test).where(Test.task_id == task_id)
    return await database.fetch_one(query) 