from fastapi import FastAPI
from app.api import task, test, report
from app.core.database import database, engine
from app.models.task import Task
from app.models.report import Report
from app.models.test import Test
from sqlalchemy.orm import declarative_base

app = FastAPI(title="鸿蒙App场景化性能测试平台")

@app.on_event("startup")
async def startup():
    Task.metadata.create_all(bind=engine)
    Report.metadata.create_all(bind=engine)
    Test.metadata.create_all(bind=engine)
    await database.connect()

@app.on_event("shutdown")
async def shutdown():
    await database.disconnect()

app.include_router(task.router)
app.include_router(test.router)
app.include_router(report.router)

@app.get("/")
def read_root():
    return {"message": "Welcome to HarmonyOS App Performance Test Platform!"} 