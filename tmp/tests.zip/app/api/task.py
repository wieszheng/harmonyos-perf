from fastapi import APIRouter
from typing import List
from app.schemas.task import TaskCreate, TaskOut
from app.services.task_service import create_task_logic, list_tasks_logic, get_task_logic

router = APIRouter(prefix="/tasks", tags=["任务管理"])

@router.post("/", response_model=TaskOut)
async def create_task(task: TaskCreate):
    task_id = await create_task_logic(task)
    task_obj = await get_task_logic(task_id)
    return task_obj

@router.get("/", response_model=List[TaskOut])
async def list_tasks():
    tasks = await list_tasks_logic()
    return tasks

@router.get("/{task_id}", response_model=TaskOut)
async def get_task(task_id: int):
    task = await get_task_logic(task_id)
    return task 