from fastapi import APIRouter
from typing import List
from app.schemas.report import ReportOut
from app.services.report_service import list_reports_logic, get_report_logic, download_report_logic

router = APIRouter(prefix="/reports", tags=["报告管理"])

@router.get("/", response_model=List[ReportOut])
async def list_reports():
    reports = await list_reports_logic()
    return reports

@router.get("/{report_id}", response_model=ReportOut)
async def get_report(report_id: int):
    report = await get_report_logic(report_id)
    return report

@router.get("/{report_id}/download", response_model=ReportOut)
async def download_report(report_id: int):
    report = await download_report_logic(report_id)
    return report 