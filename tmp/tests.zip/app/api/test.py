from fastapi import APIRouter, Body, BackgroundTasks, WebSocket, WebSocketDisconnect
from app.services.test_service import run_test_logic, get_test_status_logic, cancel_test_logic
from typing import Dict

router = APIRouter(prefix="/tasks", tags=["测试执行"])

# 全局WebSocket连接管理
active_connections: Dict[int, WebSocket] = {}

@router.post("/{task_id}/run")
async def run_test(
    task_id: int,
    device_id: str = Body(...),
    package_name: str = Body(...),
    scene: str = Body(...),
    background_tasks: BackgroundTasks = None
):
    background_tasks.add_task(run_test_logic, task_id, device_id, package_name, scene)
    return {"task_id": task_id, "status": "测试已在后台启动"}

@router.get("/{task_id}/status")
async def get_test_status(task_id: int):
    test = await get_test_status_logic(task_id)
    if test:
        return {
            "task_id": test.task_id,
            "status": test.status,
            "progress": test.progress,
            "cancelled": test.cancelled
        }
    return {"task_id": task_id, "status": "not found"}

@router.post("/{task_id}/cancel")
async def cancel_test(task_id: int):
    await cancel_test_logic(task_id)
    return {"task_id": task_id, "status": "cancelled"}

@router.websocket("/ws/tasks/{task_id}")
async def websocket_task_status(websocket: WebSocket, task_id: int):
    await websocket.accept()
    active_connections[task_id] = websocket
    try:
        while True:
            await websocket.receive_text()  # 保持连接
    except WebSocketDisconnect:
        active_connections.pop(task_id, None) 