# 鸿蒙App场景化性能测试平台

## 一、项目简介
基于 FastAPI 实现的鸿蒙App场景化性能测试平台，支持任务创建、测试执行、报告查看等功能。

## 二、目录结构

```plaintext
harmonyos-fastapi/
├── app/
│   ├── api/                # 路由层，定义各类接口
│   │   ├── task.py         # 任务相关接口
│   │   ├── test.py         # 测试执行相关接口
│   │   └── report.py       # 报告相关接口
│   ├── core/               # 核心功能/工具
│   │   ├── config.py       # 配置管理
│   │   └── scheduler.py    # 任务调度/异步执行
│   ├── models/             # 数据模型
│   │   ├── task.py
│   │   ├── report.py
│   │   └── test.py
│   ├── services/           # 业务逻辑层
│   │   ├── task_service.py
│   │   ├── test_service.py
│   │   └── report_service.py
│   ├── schemas/            # Pydantic数据校验
│   │   ├── task.py
│   │   ├── report.py
│   │   └── test.py
│   └── main.py             # FastAPI入口
├── tests/                  # 单元测试
├── requirements.txt        # 依赖
└── README.md
```

## 三、主要功能模块

1. **任务管理**
   - 创建测试任务（如：指定app、场景、参数等）
   - 查询任务列表、任务详情
   - 任务状态管理（待执行、执行中、已完成、失败等）

2. **测试执行**
   - 启动测试任务（可异步执行）
   - 监控测试进度
   - 采集性能数据（如CPU、内存、帧率等）

3. **报告管理**
   - 生成测试报告（如HTML/JSON）
   - 查询/下载报告
   - 报告可视化（如图表）

## 四、接口设计建议

### 1. 任务相关
- `POST /tasks/` 创建任务
- `GET /tasks/` 任务列表
- `GET /tasks/{task_id}` 任务详情

### 2. 测试执行
- `POST /tasks/{task_id}/run` 启动测试
- `GET /tasks/{task_id}/status` 查询任务状态

### 3. 报告相关
- `GET /reports/` 报告列表
- `GET /reports/{report_id}` 报告详情
- `GET /reports/{report_id}/download` 下载报告

## 五、实现建议
- 任务执行建议用异步（如Celery、后台线程等），避免阻塞接口。
- 报告可用数据库存元数据，文件存储实际报告内容。
- 目录结构分层清晰，便于后期维护和扩展。 